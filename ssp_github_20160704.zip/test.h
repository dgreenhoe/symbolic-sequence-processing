/*============================================================================
 * Daniel J. Greenhoe
 *============================================================================*/
extern int test_opair(void);
extern int test_vectR2(void);
extern int test_complex(void);
extern int test_seqR2(void);
extern int test_vectR6(void);

int test_otriple(void);
int test_osix(void);



extern int test_pqtheta(void);
extern int test_circle(void);

extern int test_halfcircle(void);
extern int test_circle_d1(void);
extern int test_ellipse_d1(void);
extern int test_findt(void);
extern int test_perimeter(void);
extern int test_balloon_metric(void);
extern int test_normalize(void);
//extern opair test(double t);
extern int test_dna_metric(void);
extern int test_dnan_metric(void);
extern int test_larc_metric_R2(void);
extern int test_larc_metric_R3(void);
extern int test_larc_metric_R6(void);
extern int test_mca_metric(void);
extern int test_conj(void);
extern int test_rdie_averaging(void);
extern int test_rdie_highpass(void);
extern int test_rdie(void);
extern int test_test(void);
extern int test_rdie_metric(void);
//extern int test_correlation(void);
extern int test_spinner(void);
//extern int test_rdie(void);
extern int test_die(void);
extern int test_rdie(void);
extern int test_dft_R1(void);
extern int test_dieC1(void);
extern int test_expi(void);








